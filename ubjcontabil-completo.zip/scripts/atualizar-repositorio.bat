@echo off
echo Sincronizando UBJ Contabil com o GitHub...
git add -A
set /p MSG=Mensagem do commit (ENTER para padrao): 
if "%MSG%"=="" set MSG=feat(contabil): atualizacao automatica
git commit -m "%MSG%"
git pull --rebase origin main
git push origin main
pause
