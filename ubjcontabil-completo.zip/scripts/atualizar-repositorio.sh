#!/usr/bin/env bash
set -e
echo "Sincronizando UBJ Contabil com o GitHub..."
git add -A
read -p "Mensagem do commit (ENTER para padrao): " MSG
if [ -z "$MSG" ]; then
    MSG="feat(contabil): atualizacao em $(date '+%d/%m/%Y %H:%M:%S')"
fi
git commit -m "$MSG" || true
git pull --rebase origin main || true
git push origin main
echo "Sucesso!"
