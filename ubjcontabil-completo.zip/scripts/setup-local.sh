#!/usr/bin/env bash
set -e
echo "Configurando UBJ Contabil localmente..."
if [ ! -f "package.json" ]; then
    echo "ERRO: package.json nao encontrado no diretorio atual."
    exit 1
fi
if [ ! -f ".env" ] && [ -f ".env.example" ]; then
    cp .env.example .env
fi
npm install
echo "Iniciando servidor em http://localhost:3000..."
npm run dev
