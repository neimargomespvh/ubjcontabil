@echo off
echo Configurando UBJ Contabil localmente...
if not exist "package.json" (
    echo ERRO: package.json nao encontrado nesta pasta.
    pause
    exit /b 1
)
if not exist ".env" if exist ".env.example" copy .env.example .env
call npm install
echo Iniciando servidor em http://localhost:3000...
call npm run dev
