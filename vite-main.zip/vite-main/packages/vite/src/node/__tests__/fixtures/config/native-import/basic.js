export default {
  value: 'works',
}
