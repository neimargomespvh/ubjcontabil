export default 'dollar-double'
