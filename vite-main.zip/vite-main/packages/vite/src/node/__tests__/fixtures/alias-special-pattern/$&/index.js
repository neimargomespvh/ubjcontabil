export default 'dollar-ampersand'
