"""Sincronizador Delta local→nuvem."""
