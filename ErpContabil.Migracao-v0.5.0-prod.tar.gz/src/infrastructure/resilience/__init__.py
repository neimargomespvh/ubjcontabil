"""Políticas de retry."""
