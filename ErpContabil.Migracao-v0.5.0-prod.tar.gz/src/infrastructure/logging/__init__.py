"""Logger resiliente."""
