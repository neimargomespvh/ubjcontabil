"""Métricas de execução."""
