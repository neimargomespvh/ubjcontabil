"""Enumerações do domínio."""
