"""Autenticação JWT + Basic (compat) e auditoria de ações do painel Admin."""
from __future__ import annotations

import logging
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Annotated, Any

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import (
    HTTPAuthorizationCredentials,
    HTTPBasic,
    HTTPBasicCredentials,
    HTTPBearer,
)
from passlib.context import CryptContext
from pydantic import BaseModel

log = logging.getLogger("migracao.auth")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
_JWT_SECRET = os.environ.get("JWT_SECRET", "")
_JWT_ALGO = "HS256"
_JWT_EXPIRE_MIN = int(os.environ.get("JWT_EXPIRE_MINUTES", "480"))
_ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
_ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")

_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
_basic = HTTPBasic(auto_error=False)
_bearer = HTTPBearer(auto_error=False)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class TokenPayload(BaseModel):
    sub: str
    exp: int
    iat: int


def _require_secrets() -> None:
    if not _ADMIN_PASSWORD:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="ADMIN_PASSWORD não configurada no servidor",
        )
    if not _JWT_SECRET or len(_JWT_SECRET) < 32:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="JWT_SECRET deve ter pelo menos 32 caracteres",
        )


def verify_password(plain: str, expected: str) -> bool:
    """Compara senha em texto (config via env) de forma segura."""
    return secrets.compare_digest(plain, expected)


def create_access_token(username: str) -> TokenResponse:
    """Gera JWT assinado para o usuário autenticado."""
    _require_secrets()
    now = datetime.now(timezone.utc)
    expire = now + timedelta(minutes=_JWT_EXPIRE_MIN)
    payload = {
        "sub": username,
        "iat": int(now.timestamp()),
        "exp": int(expire.timestamp()),
    }
    token = jwt.encode(payload, _JWT_SECRET, algorithm=_JWT_ALGO)
    return TokenResponse(
        access_token=token,
        expires_in=_JWT_EXPIRE_MIN * 60,
    )


def decode_token(token: str) -> TokenPayload:
    try:
        data = jwt.decode(token, _JWT_SECRET, algorithms=[_JWT_ALGO])
        return TokenPayload(**data)
    except jwt.ExpiredSignatureError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expirado",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc
    except jwt.PyJWTError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


def login_basic(
    creds: HTTPBasicCredentials | None = Depends(_basic),
) -> TokenResponse:
    """Endpoint de login: valida Basic e devolve JWT."""
    _require_secrets()
    if creds is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais obrigatórias",
            headers={"WWW-Authenticate": "Basic"},
        )
    ok_user = secrets.compare_digest(str(creds.username), _ADMIN_USER)
    ok_pass = verify_password(str(creds.password), _ADMIN_PASSWORD)
    if not (ok_user and ok_pass):
        log.warning("Falha de login para usuário=%s", creds.username)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais inválidas",
            headers={"WWW-Authenticate": "Basic"},
        )
    log.info("Login OK: user=%s", creds.username)
    return create_access_token(str(creds.username))


def get_current_user(
    bearer: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)] = None,
    basic: Annotated[HTTPBasicCredentials | None, Depends(_basic)] = None,
) -> str:
    """Dependência FastAPI: exige JWT (preferido) ou Basic (compat)."""
    _require_secrets()

    # 1) Bearer JWT
    if bearer and bearer.credentials:
        payload = decode_token(bearer.credentials)
        return payload.sub

    # 2) Fallback HTTP Basic (compatibilidade com scripts/curl antigos)
    if basic is not None:
        ok_user = secrets.compare_digest(str(basic.username), _ADMIN_USER)
        ok_pass = verify_password(str(basic.password), _ADMIN_PASSWORD)
        if ok_user and ok_pass:
            return str(basic.username)

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Autenticação obrigatória (Bearer JWT ou Basic)",
        headers={"WWW-Authenticate": "Bearer"},
    )


# Alias legado usado pelo app
verificar_admin = get_current_user


# ---------------------------------------------------------------------------
# Auditoria
# ---------------------------------------------------------------------------
def audit(action: str, user: str, detail: str = "", request: Request | None = None) -> None:
    """Registra ação administrativa em log estruturado."""
    ip = "-"
    if request is not None:
        ip = request.client.host if request.client else "-"
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            ip = forwarded.split(",")[0].strip()
    log.info(
        "AUDIT user=%s action=%s ip=%s detail=%s",
        user,
        action,
        ip,
        detail[:500] if detail else "-",
    )
