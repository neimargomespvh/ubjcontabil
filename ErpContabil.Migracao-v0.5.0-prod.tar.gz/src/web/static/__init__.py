"""Pacote gerado automaticamente."""
