"""Helpers compartilhados entre extractors."""
