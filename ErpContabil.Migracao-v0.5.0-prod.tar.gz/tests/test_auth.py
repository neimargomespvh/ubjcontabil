"""Testes de autenticação JWT + Basic do painel Admin."""
from __future__ import annotations

import base64
import os

import pytest
from fastapi.testclient import TestClient


def _basic(user: str, senha: str) -> dict[str, str]:
    token = base64.b64encode(f"{user}:{senha}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


@pytest.fixture
def client(monkeypatch: pytest.MonkeyPatch) -> TestClient:
    monkeypatch.setenv("ADMIN_USER", "admin")
    monkeypatch.setenv("ADMIN_PASSWORD", "senha-forte-123")
    monkeypatch.setenv("JWT_SECRET", "test-secret-key-at-least-32-characters-long")
    # Garante que módulos de auth leiam o env atualizado
    import importlib
    import src.web.auth as auth_mod
    importlib.reload(auth_mod)
    from src.web.app import app
    return TestClient(app, raise_server_exceptions=False)


def test_health_publico(client: TestClient) -> None:
    r = client.get("/api/migracao/health")
    assert r.status_code == 200
    body = r.json()
    assert "status" in body


def test_rota_protegida_sem_credenciais(client: TestClient) -> None:
    r = client.post(
        "/api/migracao/fortes/testar",
        json={"host": "x", "database": "y", "usuario": "z", "senha": "w"},
    )
    assert r.status_code == 401
    assert "WWW-Authenticate" in r.headers


def test_rota_protegida_senha_errada(client: TestClient) -> None:
    r = client.post(
        "/api/migracao/fortes/testar",
        json={"host": "x", "database": "y", "usuario": "z", "senha": "w"},
        headers=_basic("admin", "senha-errada"),
    )
    assert r.status_code == 401


def test_login_emite_jwt(client: TestClient) -> None:
    r = client.post("/api/auth/login", headers=_basic("admin", "senha-forte-123"))
    assert r.status_code == 200
    body = r.json()
    assert "access_token" in body
    assert body["token_type"] == "bearer"
    assert body["expires_in"] > 0


def test_acesso_com_jwt(client: TestClient) -> None:
    login = client.post("/api/auth/login", headers=_basic("admin", "senha-forte-123"))
    token = login.json()["access_token"]
    r = client.get(
        "/api/migracao/jobs",
        headers={"Authorization": f"Bearer {token}"},
    )
    # Pode ser 200 (lista vazia) ou 500 se DB offline — o importante é não ser 401
    assert r.status_code != 401


def test_admin_sem_env_falha_fechado(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("ADMIN_PASSWORD", raising=False)
    import importlib
    import src.web.auth as auth_mod
    importlib.reload(auth_mod)
    r = client.post(
        "/api/migracao/fortes/testar",
        json={"host": "x", "database": "y", "usuario": "z", "senha": "w"},
        headers=_basic("admin", "qualquer"),
    )
    assert r.status_code in (401, 500)
